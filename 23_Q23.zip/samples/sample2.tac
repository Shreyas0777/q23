t1 = a + b
t2 = c * d
t3 = t1 - t2
x = t3
